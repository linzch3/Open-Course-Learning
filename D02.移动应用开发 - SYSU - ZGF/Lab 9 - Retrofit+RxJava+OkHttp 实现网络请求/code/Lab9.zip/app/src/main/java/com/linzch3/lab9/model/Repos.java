package com.linzch3.lab9.model;

/**
 * Created by linzch3 on 17/12/19.
 */

public class Repos
{
    private String name, language, description;

    public String getName()
    {
        return name;
    }

    public String getLanguage()
    {
        return language;
    }

    public String getDescription()
    {
        return description;
    }
}
