package com.linzch3.lab9.model;

/**
 * Created by linzch3 on 17/12/19.
 */

public class Github
{
    private int id;
    private String login, blog;

    public int getId()
    {
        return id;
    }

    public String getLogin()
    {
        return login;
    }

    public String getBlog()
    {
        return blog;
    }
}
